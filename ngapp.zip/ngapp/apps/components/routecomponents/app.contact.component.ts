import { Component,OnInit } from '@angular/core';
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the cl} from '@angular/core';

    @Component({
        selector: "app-contact-component",
        template:
        `<h2> Contact Component</h2>
        <div class ="container">{{message}} </div>
        <br />
       
        <a [routerLink]='["product"]' >Product  </a>
        <router-outlet></router-outlet>
        <tr>`
    })

    export class ContactComponent implements OnInit{
        message :string;
        constructor(){
            this.message = "I am contact Component";
        }
    

    ngOnInit():void{}
}