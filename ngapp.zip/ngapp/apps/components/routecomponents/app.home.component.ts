import { Component,OnInit } from '@angular/core';
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the cl} from '@angular/core';
import { Router,ActivatedRoute } from "@angular/router";

import { UserService } from "./../../services/app.usre.service";
    @Component({
        selector: "app-home-component",
        template:
        `<h2> Home Component</h2>
        <div class ="container">{{message}} </div>
        <br />
        <br/>
        UserName:<input id="uname"  name = "UserName" type="text" value=""/>
        <br/>
        Password:<input id="pword"  name = "Password" type="text" value=""/>
        <br/>
        
        <input type="button" value = "Login" (click)="SignInUser()"/>
        <input type="button" value = "SignUp" (click)="SignUpUser()"/>
        <br />
       
        <router-outlet></router-outlet>`
    })

    export class HomeComponent implements OnInit{
        message :string;
        constructor(private router:Router,private act:ActivatedRoute){
            this.message = "I am home Component";
        }
        SignInUser():void{
            this.router.navigate(["login"]);
        }
        SignUpUser():void{
            this.router.navigate(["signup"]);
        }

    ngOnInit():void{}
}