import { Component,OnInit } from '@angular/core';
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the cl} from '@angular/core';
    import { Router , ActivatedRoute} from "@angular/router";
    import { UserService } from "./../../services/app.usre.service";
    import {Request, Response } from "@angular/http";
    import { User } from "./../../models/app.user.model";

    @Component({
        selector: "app-login-component",
        template:
        `<h2> Login Component</h2>
        
        <br/>
        <br/>
        UserName:<input id="uname" type="text" name = "UserName" [(ngModel)]='user.UserName' />
        <br/>
        Password:<input id="pword" type="text" name = "Password" [(ngModel)]="user.Password" />
        <input type="button" value = "SignIn" (click)="signInUser()" />`
    })

    export class LoginComponent implements OnInit{
    
        user:User;
        users:Array<User>;

        constructor(private serve:UserService){
            this.user = new User("", "");
            this.users = new Array<User>();
                      
        }
    

        signInUser():void{
            console.log("method call");
            
            console.log(this.user.UserName);

         this.serve.login(this.user).subscribe(
            (resp:Response) => {
                console.log(resp);
                console.log(resp.json().data);
                this.users.push(resp.json().data);
            },
            error =>{
                console.log(`Error occured ${error}`);
                
            }
         )   
            
        }

    ngOnInit():void{}
}