import { Component,OnInit } from '@angular/core';
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the cl} from '@angular/core';
import { Router , ActivatedRoute} from "@angular/router";
    @Component({
        selector: "app-about-component",
        template:
        `<h2> About Component</h2>
        <div class ="container">{{message}} </div>
        <br/>
        <div class= "container">The value is:{{value}}</div>
        <br/>
        <input type="button" value = "Navigate to contact" (click)="navigateToContact()"/>`
    })

    export class AboutComponent implements OnInit{
        message :string;
        value:number;
        //the injcetion of router will fetch router object from RouterModule imported in NgModule using "Routing"
        constructor(private router:Router,private act:ActivatedRoute){
            this.message = "I am About Component";
        }
    
//explicitly routed to contact
        navigateToContact():void{
            this.router.navigate(["contact"]);
        }
//subscribe to parameters from ActivatedRoute oject
    ngOnInit():void{
        this.act.params.subscribe(params=>{
            this.value = params.id;
        });
    }
}