import { Component, OnInit,Input, Output } from '@angular/core';
import {Product,Products} from './../../models/apps.productchild.model'; 
@Component({
    selector: 'product-data',
    templateUrl: './products.html'
})
export class ProductChildComponent implements OnInit {
    products = Products
    _filterProduct:Array< Product >;
    _categoryId:number;
     
  @Input()
  set categoryId(catId: number) {
    this._categoryId = catId  || 0;
  }
  get categoryId() { 
      return this._categoryId; 
  }    
 
  
    constructor() { 
         this._filterProduct = new Array< Product >();
         console.log('Product');
    } 
 
  get filterProducts() { 
           this._filterProduct = new Array< Product >();
          for(let e of Products){
            if(e.categoryId==this._categoryId){
                this._filterProduct.push(e);
            }
        } 
      return this._filterProduct; 
    }
 
    ngOnInit() { }
}