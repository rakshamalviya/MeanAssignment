
import { Component, OnInit } from '@angular/core';
import {Category,Categories} from './../../models/apps.categoryparent.model';
 
@Component({
    selector: 'category-data',
    templateUrl: './category.html'
})
export class CategoryComponent implements OnInit {
    categories=Categories;
    categoryId:number;
    constructor() {
        this.categoryId = 0;
     }
     selectCategory(c:any){
         this.categoryId = c.categoryId;
     }
 
    ngOnInit() { }
}