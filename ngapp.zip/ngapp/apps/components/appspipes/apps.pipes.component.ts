import {Component} from "@angular/core";
import { componentFactoryName } from "@angular/compiler";
import { stringify } from "@angular/core/src/util";
import {Product} from "./../../models/app.product.model"
 


@Component({
    selector : "app-piped-component",
    template:`
    <div class ="container">
    <strong> The angular pipes</strong>
    </div>
    <br/>
    <div class= "container">
    <span>{{name|uppercase}}</span>
    <br/>
    <span>{{name|lowercase}}</span>
    </div>
    <br/>
    <div class= "container">
    <span>{{dob | date:"short"}}</span>
    <br/>
    <span>{{dob | date:"medium"}}</span>
    <br/>
    <span>{{dob | date:"full"}}</span>
    <br/>
    <span>{{dob | date:"M/dd/yyyy"}}</span>
    </div>
    <br/>
    <div class= "container">
    <span>{{salary|currency:"INR"}}</span>
    </div>
    <div class= "container">
    <span>{{prd | json }}</span>
    </div>`
})

export class PipedComponent{
    name:string;
    dob:Date;
    salary:Number;
    prd:Product;
    constructor(){
       this.name = "Harbinger systems!!";
       this.dob = new Date(2019,1,2);
       this.salary = 20000;
       this.prd = new Product("12345","S1","P1","C1","M1",4444);
    }
}