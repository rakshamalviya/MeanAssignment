export class Product{
    constructor(
        public _id:string,
        public ProductId:string,
        public ProductName :string,
        public CategoryName:string,
        public Manufacturer:string,
        public Price:number
    ){}
}