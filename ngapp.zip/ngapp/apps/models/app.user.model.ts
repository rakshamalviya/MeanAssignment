export class User{
    constructor(
        public UserName:string,
        public Password:string
    ){}
}