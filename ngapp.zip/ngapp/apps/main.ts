// Angular module file
// 1. import all standarad / required modules
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { Categories } from "./components/productcomponent/app.product.model";
import { ProductComponent } from "./components/productcomponent/app.product.component";
import { platformBrowserDynamic } from "@angular/platform-browser-dynamic";
import { AppGuardService } from "./services/app.test.guard.service";

// 2. import all required component 
import { SimpleComponent } from "./components/simplecomponent/app.simple.component";
import { ProductFormComponent } from "./components/productformcomponent/app.productform.component";
import { SampleService } from "./services/app.sample.service";
import { SampleServiceComponent } from "./components/sampleservice/app.sampleservice.component";
import { ProductServiceComponent } from "./components/productserviecomponent/app.productservice.component";
import { HttpModule } from "@angular/http";
import { ProductService } from "./services/app.products.service";
import { CategorySenderComponent } from "./components/categorycomponent/app.categorysender.component";
import { ProductReceiverComponent } from "./components/categorycomponent/app.categoryreceiver.component";
import { CommunicationService } from "./services/app.communication.service";
import { CategoryComponent } from "./components/categoryproductcomponent/apps.category.component";
import { ProductChildComponent } from "./components/categoryproductcomponent/apps.productchild.component";
import { routing } from "./components/routecomponents/apps.route.table";
import { MainComponent } from "./components/routecomponents/app.main.component";
import { HomeComponent } from "./components/routecomponents/app.home.component";
import { ContactComponent } from "./components/routecomponents/app.contact.component";
import { AboutComponent } from "./components/routecomponents/app.about.component";
import { ErrorComponent } from "./components/routecomponents/app.error.component";
import { LoginComponent } from "./components/routecomponents/app.login.component";
import { SignUpComponent } from "./components/routecomponents/app.signup.component";
import {UserService  } from "./services/app.usre.service";
import { PipedComponent } from "./components/appspipes/apps.pipes.component";

// 3. import all directives
@NgModule({
    imports:[BrowserModule, FormsModule, ReactiveFormsModule, HttpModule,routing],
    declarations:[LoginComponent,PipedComponent,ProductFormComponent, ProductComponent, SampleServiceComponent ,ProductReceiverComponent,CategorySenderComponent,
         ProductServiceComponent,SignUpComponent,AboutComponent,LoginComponent,ErrorComponent,ProductComponent,CategoryComponent,ProductChildComponent,MainComponent,HomeComponent,ContactComponent], // declare all components ... lazy loading
    providers:[UserService,SampleServiceComponent, ProductService, SampleService,CommunicationService,AppGuardService], // service provider class
    bootstrap:[PipedComponent]
})
export class AppModule{}

// 4. making app module as bootstrap module
platformBrowserDynamic().bootstrapModule(AppModule);