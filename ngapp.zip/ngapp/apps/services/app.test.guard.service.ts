import { Injectable } from "@angular/core";
import { CanActivate,Router,
     ActivatedRouteSnapshot, 
     RouterState, 
     RouterStateSnapshot } from "@angular/router";



@Injectable()
export class AppGuardService implements CanActivate{

    constructor(private _router:Router){}
    canActivate(
        route:ActivatedRouteSnapshot,
        state:RouterStateSnapshot
    ):boolean{
        console.log("canActivate");

        alert(
            "You are not allowed to view this page . You are redirected to Error page"
        );

        this._router.navigate(["error"]);

        return false;
    }
    
}