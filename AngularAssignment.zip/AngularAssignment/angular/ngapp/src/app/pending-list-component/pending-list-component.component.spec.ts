import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingListComponentComponent } from './pending-list-component.component';

describe('PendingListComponentComponent', () => {
  let component: PendingListComponentComponent;
  let fixture: ComponentFixture<PendingListComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PendingListComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingListComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
