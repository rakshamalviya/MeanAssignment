import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pending-list-component',
  templateUrl: './pending-list-component.component.html',
  styleUrls: ['./pending-list-component.component.css']
})
export class PendingListComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
