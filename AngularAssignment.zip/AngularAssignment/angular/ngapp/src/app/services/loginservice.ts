import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import { Users } from './../Model/usersmodel';
import { LoginModel } from './../Model/loginmodel'

@Injectable()
export class LoginService {


    url: string;
    constructor(private http: Http){
        this.url = 'http://localhost:4040';
    }

    // getData(): Observable<Response>{
    //     let resp: Observable<Response>;
    //     resp = this.http.get(`${this.url}/api/users`);
    //     return resp;
    // },

    verifyUser(login: LoginModel): Observable<Response>{
      console.log("in verify user");
      let resp: Observable<Response>;
      // 1. define request header
      let header: Headers = new Headers({'Content-Type': 'application/json'});
     // header.append("AUTHORIZATION", "Basic UserName:Password");

     // 2. define request option for header
      // collecton of the header values
     let options: RequestOptions = new RequestOptions();
     options.headers = header;
      resp = this.http.post(`${this.url}/api/users/auth`, JSON.stringify(login), options);
      console.log(JSON.stringify(resp));
     return resp;
  }


}
