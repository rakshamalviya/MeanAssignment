import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import { Roles } from './../Model/roleModel';


@Injectable()
export class RoleService {


    url: string;
    constructor(private http: Http){
        this.url = 'http://localhost:4040';
    }

    // getData(): Observable<Response>{
    //     let resp: Observable<Response>;
    //     resp = this.http.get(`${this.url}/api/users`);
    //     return resp;
    // },

    createRole(role: Roles,token: string): Observable<Response>{
      console.log('in create roles');
      let resp: Observable<Response>;
      let header: Headers = new Headers({'Content-Type': 'application/json'});
     header.append('Authorization', token);

     let options: RequestOptions = new RequestOptions();

     options.headers = header;
     console.log(JSON.stringify(options.headers))
      resp = this.http.post(`${this.url}/api/role`, JSON.stringify(role) ,options);
      console.log(JSON.stringify(resp));
     return resp;
  }


}
