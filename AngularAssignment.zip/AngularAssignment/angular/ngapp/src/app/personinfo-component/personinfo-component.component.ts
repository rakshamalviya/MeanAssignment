import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personinfo-component',
  templateUrl: './personinfo-component.component.html',
  styleUrls: ['./personinfo-component.component.css']
})
export class PersoninfoComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
