import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersoninfoComponentComponent } from './personinfo-component.component';

describe('PersoninfoComponentComponent', () => {
  let component: PersoninfoComponentComponent;
  let fixture: ComponentFixture<PersoninfoComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersoninfoComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersoninfoComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
