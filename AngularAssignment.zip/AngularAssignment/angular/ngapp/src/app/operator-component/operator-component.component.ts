import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operator-component',
  templateUrl: './operator-component.component.html',
  styleUrls: ['./operator-component.component.css']
})
export class OperatorComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
