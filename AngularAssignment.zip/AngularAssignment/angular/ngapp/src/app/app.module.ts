import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ReactiveFormsModule,FormsModule} from '@angular/forms';
import { routing } from './app-routing.module';
import { AppComponent } from './app.component';
import { MyNewComponentComponent } from './my-new-component/my-new-component.component';
import { AdminComponentComponent } from './admin-component/admin-component.component';
import { OperatorComponentComponent } from './operator-component/operator-component.component';
import { AccessUserComponentComponent } from './access-user-component/access-user-component.component';
import { LoginComponentComponent } from './login-component/login-component.component';
import { RoleComponentComponent } from './role-component/role-component.component';
import { HomeComponentComponent } from './home-component/home-component.component';
import { PersoninfoComponentComponent } from './personinfo-component/personinfo-component.component';
import { PendingListComponentComponent } from './pending-list-component/pending-list-component.component';
import { LoginService} from './services/loginservice';
import {HttpModule} from "@angular/http";
import { platformBrowserDynamic } from "@angular/platform-browser-dynamic";
import { UserComponent } from './user/user.component';
import { PersonComponent } from './person/person.component';
import {RoleService} from './services/RoleService';


@NgModule({
  declarations: [
    AppComponent,
    MyNewComponentComponent,
    AdminComponentComponent,
    OperatorComponentComponent,
    AccessUserComponentComponent,
    LoginComponentComponent,
    RoleComponentComponent,
    HomeComponentComponent,
    PersoninfoComponentComponent,
    PendingListComponentComponent,
    UserComponent,
    PersonComponent
      ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    HttpModule,
    routing
  ],
  providers: [ LoginService, RoleService ],
  bootstrap: [AppComponent]
})
export class AppModule {}
platformBrowserDynamic().bootstrapModule(AppModule);


