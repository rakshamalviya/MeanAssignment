import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-access-user-component',
  templateUrl: './access-user-component.component.html',
  styleUrls: ['./access-user-component.component.css']
})
export class AccessUserComponentComponent implements OnInit {

  constructor(private router: Router , private act: ActivatedRoute) { }

  updatePerson(): void {
    this.router.navigate(['SuccessPage']);
}
  ngOnInit() {
  }

}
