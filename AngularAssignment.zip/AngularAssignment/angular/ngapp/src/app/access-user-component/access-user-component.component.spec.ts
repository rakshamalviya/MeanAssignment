import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccessUserComponentComponent } from './access-user-component.component';

describe('AccessUserComponentComponent', () => {
  let component: AccessUserComponentComponent;
  let fixture: ComponentFixture<AccessUserComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccessUserComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccessUserComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
