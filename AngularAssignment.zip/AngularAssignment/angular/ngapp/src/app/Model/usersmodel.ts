export class Users {
    constructor(
        public userId: number,
        public userName: string,
        public password: string,
        public emailAddress: string,
        public roleId: number,
    ) {}
}
