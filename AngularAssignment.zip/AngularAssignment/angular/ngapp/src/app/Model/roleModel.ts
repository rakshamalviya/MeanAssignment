export class Roles {
  constructor(
    RoleId: number,
    RoleName: string
  ) {}
}
