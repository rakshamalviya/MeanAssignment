export class LoginModel {
    constructor(
        public UserName: string,
        public Password: string,

    ) {}
}
