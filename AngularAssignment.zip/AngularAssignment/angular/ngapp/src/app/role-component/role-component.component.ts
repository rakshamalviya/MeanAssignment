import { Component, OnInit } from '@angular/core';
import { Roles } from '../Model/roleModel';
import { RoleService } from './../services/RoleService';
import { Router, ActivatedRoute } from '@angular/router';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { ReactiveFormsModule, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-role-component',
  templateUrl: './role-component.component.html',
  styleUrls: ['./role-component.component.css']
})
export class RoleComponentComponent implements OnInit {
role: Roles;
token = sessionStorage.getItem('token');

  constructor(private serv: RoleService, private router: Router) {
    this.role = new Roles( 0, '');
   }

  ngOnInit() {
  }

  createRole(): void {
    console.log(JSON.stringify(this.role));
    console.log(JSON.stringify(this.token));
    this.serv.createRole(this.role,this.token).subscribe(
      (result: Response) => {
        if (result.json().authenticated) {


            this.router.navigate(['roles']);

            }
          },
      error => {
        console.log(`Error occured ${error}`);
      }
    );

  }

}
