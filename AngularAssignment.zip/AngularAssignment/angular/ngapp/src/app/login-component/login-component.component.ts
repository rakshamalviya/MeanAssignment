import { Component, OnInit } from '@angular/core';
import { LoginModel } from './../Model/loginmodel';
import { LoginService } from './../services/loginservice';
import { Router, ActivatedRoute } from '@angular/router';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { ReactiveFormsModule, FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login-component.component.html',
  styleUrls: [
    './login-component.component.css'
  ]
})
export class LoginComponentComponent implements OnInit {
  user: LoginModel;

  constructor( private serv: LoginService, private router: Router) {
    this.user = new LoginModel('', '');
  }


  ngOnInit() {}
  onSubmit(): void {
    console.log(JSON.stringify(this.user));

    this.serv.verifyUser(this.user).subscribe(

      (result: Response) => {

        if (result.json().authenticated) {

          if (result.json().data.RoleId === 1) {
            this.router.navigate(['admin']);
          } else if (result.json().data.RoleId === 2) {
            this.router.navigate(['operator']);
          } else if (result.json().data.RoleId === 3) {
              this.router.navigate(['accessuser']);
          }
        }
      },
      error => {
        console.log(`Error occured ${error}`);
      }
    );
  }
}
