// import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponentComponent } from './login-component/login-component.component';
import { AccessUserComponentComponent } from './access-user-component/access-user-component.component';
import { AdminComponentComponent } from './admin-component/admin-component.component';
import { OperatorComponentComponent } from './operator-component/operator-component.component';
import { RoleComponentComponent } from './role-component/role-component.component';
import { HomeComponentComponent } from './home-component/home-component.component';
import { PersoninfoComponentComponent } from './personinfo-component/personinfo-component.component';
import { PendingListComponentComponent } from './pending-list-component/pending-list-component.component';
import { ModuleWithProviders } from '@angular/core';
import { UserComponent } from './user/user.component';
import { PersonComponent } from './person/person.component';

const routes: Routes = [	{
  path: '',
  component: LoginComponentComponent,

},
{
  path: 'accessuser',
  component: AccessUserComponentComponent,

},
{
  path: 'admin',
  component: AdminComponentComponent, children: [
    {path: 'role', component: RoleComponentComponent},
  {path: 'user', component: UserComponent}]

},
{
  path: 'operator',
  component: OperatorComponentComponent,

},
{
  path: 'role',
  component: RoleComponentComponent,

},
{
  path: 'home',
  component: HomeComponentComponent,

},
{
  path: 'personinfo',
  component: PersoninfoComponentComponent,

},
{
  path: 'pendinglist',
  component: PendingListComponentComponent,

},
{
  path: 'user',
  component: UserComponent,

},
{
  path: 'person',
  component: PersonComponent,

}
];
export const routing: ModuleWithProviders = RouterModule.forRoot(routes);



