export class Login{
    constructor(
        public userName:String,
        public password:String 
    ){}
}