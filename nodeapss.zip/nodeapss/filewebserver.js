var http = require('http');
var fs = require('fs');

//1/create a server object with listener
var server  = http.createServer(function(request,response){

//2. parse the request and read url
if(request.url==='/home'){
//2a.read for home page
fs.readFile('./home.html',function(err,data){
    if(err){
        response.writeHead(401,{"Content-type":"text/html"});
        response.write("Resorce you are looking for is not available");
        response.end();
    }
    response.writeHead(200,{"Content-type":"text/html"});
    response.write(data);
    response.end();
});
}

else{
    if(request.url==='/about'){
        //2b.read for about page
        fs.readFile('./about.html',function(err,data){
            if(err){
                response.writeHead(401,{"Content-type":"text/html"});
                response.write("Resorce you are looking for is not available");
                response.end();
            }
            response.writeHead(200,{"Content-type":"text/html"});
            response.write(data);
            response.end();
        });
        }

    }


});
server.listen(4060);

console.log("servere started on port 4060");

