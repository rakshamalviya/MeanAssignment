var fs = require('fs');

//1. write file using asyn call
fs.writeFile('./myasynfile.txt',"I am an asyn file",function(err){
    if(err){
    console.log(err.message);
    return;
}
console.log("file written succesfully");
fs.readFile("./myasynfile.txt",function(err,data){
    if(err){
        console.log(err.message);
        return;
    }
    console.log(data.toString());
});
}
)
console.log("DONE");
fs.appendFile('./myasynfile.txt'," I am appended an file",function(err){
    if(err){
        console.log(err.message);
        return;
}
console.log("file appended successfully");
}
    )
fs.mkdir('./myasynfile2',function(err){
    if(err){
        console.log(err.message);
        return;
}
console.log("Directory created successfully");
})

fs.rmdir('./myasynfile1',function(err){
    if(err){
        console.log(err.message);
        return;
}
console.log("Directory deleted successfully");
})