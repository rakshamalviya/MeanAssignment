//5c. Map the schema with the collection
//5b define schema (recommended to have same aatibutes as per the collection)
var userSchema = mongoose.Schema({
    UserId:Number,
    Password:String
   
});          

var productSchema = mongoose.Schema({
    ProductId:Number,
    ProductName:String,
    CategoryName:String,
    Manufacturer:String,
    Price:Number
});
var productModel = mongoose.model("Products",productSchema,"Products");

//    name    schema        collection
 var usrModel = mongoose.model("UserModel",userSchema,"UserModel");

module.exports={
    createUser:function(){
usrModel.create(user,function(err,res){
    //6b. if error occurred the response error
    if(err){
        response.statusCode = 500;
        response.send({status: response.statusCode,error:err});
        return;
    }
    response.send({status:200,data:res});

     });
    },

    getProducts:function(){
     productModel.find().exec(function(err,res){
        //6b. if error occurred the response error
        if(err){
            response.statusCode = 500;
            response.send({status: response.statusCode,error:err});
            
        }
        response.send({status:200,data:res});
    }) ;   
}
}

