//1. Loas express 
var express = require('express');
//1a. load the 'path' module. Ths will be used by static middleware of express.
//The path is the standard node module
var path = require('path');
//1b. import the data module 
var userModel =  require('./usermodel');

var dataModel =  require('./datamodel');

//1c. load the body parser
var bodyParser =  require('body-parser');
//1d. loading mongoose driver
var mongoose = require("mongoose");
//1e. set the global promise to manage all asyncalls made by appl using mongoose driver
mongoose.Promise = global.Promise;
//2. define an instance of express
var instance = express();
//2a. load cors
//var cors = require("cors");

//3. configure all middlewares 
//3a. static files
// //use is used for configuring middleware or adding them on express instance
// instance.use(express.static(path.join(__dirname,'./../node_modules/jquery/dist')
// )
// );
//3. define express - router , for saggregating urls for html page and rest api requests
var router = express.Router();

//3c. add the router object in the express middleware 
instance.use(router);

//3d. configure the body parser middleware
//3d.1 use urlencoded as false to read data from http url as querystring/formmodel etc.
instance.use(bodyParser.urlencoded({extended:false}));

//3d.2 use the json() parser for body parser
instance.use(bodyParser.json());
//3e. configure cors
//instance.use(cors({}))

//4. create web request handlers 
//4a. this will return the home.html from views folder
router.get("/home",function(req,resp){
    resp.sendFile("home.html",{
        root: path.join(__dirname,"./../views")
    });
});
//5. Model-schema mapping with collection on mongo db 
//and establishing connection with it
mongoose.connect("mongodb://localhost/ProductsAppDb",
{
    useNewUrlParser:true
});

//5a. get the connection object
//if db connect is not undefined then the connection is successful
var dbConnect = mongoose.connection;
if(!dbConnect){
    console.log("SOrry connection has not been set");
    return;
}
// //5b define schema (recommended to have same aatibutes as per the collection)
// var userSchema = mongoose.Schema({
//     UserId:Number,
//     Password:String
   
// });

// var productSchema = mongoose.Schema({
//     ProductId:Number,
//     ProductName:String,
//     CategoryName:String,
//     Manufacturer:String,
//     Price:Number
// });

// //5c. Map the schema with the collection
//                                 //    name    schema        collection
// var usrModel = mongoose.model("UserModel",userSchema,"UserModel");

// var productModel = mongoose.model("Products",productSchema,"Products");


instance.post("/api/users",function(request,response){
     //5a. read headers for AUTHORIZATION values
     var authValue = request.headers.authorization;
     //5b. Process values
     //thake only username and pswd
     var credentials = authValue.split(" ")[1];
     //if( undefined!=authValue && null!=authValue.split(" ")[0]&& "Basic"==authValue.split(" ")[0]){
         
     var data = credentials.split(":");
     var username = data[0];
     var password = data[1];
     //5c. May access UserModel from Database(?)
     

     if(username =="Admin" && password=="Admin"){
        var user ={
            UserId:request.body.UserId,
            Password:request.body.Password
        };  
    
        usrModel.create(user,function(err,res){
            //6b. if error occurred the response error
            if(err){
                response.statusCode = 500;
                response.send({status: response.statusCode,error:err});
                return;
            }
            response.send({status:200,data:res});

             });
       
 
       
 
 }else{
     response.statusCode =402;
     response.send({
         status: response.statusCode,
         message:"Not Authenticated user"
     });
 }
//}
   
});








instance.get("/api/products",function(request,response){

    var result;
    function validate(){

        var authValue = request.headers.authorization;
     //5b. Process values
     //thake only username and pswd
     var credentials = authValue.split(" ")[1];
     //if( undefined!=authValue && null!=authValue.split(" ")[0]&& "Basic"==authValue.split(" ")[0]){
         
     var data = credentials.split(":");
     var username = data[0];
     var password = data[1];

    
      result = usrModel.findOne({
          
              $and:[ { "UserId":username} ,{ "Password":password }
          ]
      

    });
}
    if(null!=result){
    //6a. make call to db for a collection mapped with model
    // and expect all documnets from it
  
};
    
    });











//6. start listening 
instance.listen(4070,function(){
    console.log("start listening on port 4070");
});