var Products =[
    {id:101,"name":"P1"},
    {id:102,"name":"P2"}
];

module.exports={
    getData:function(){
        return Products;
    },
    addData:function(prd){
        Products.push(prd);
        return Products;
    },
    delete:function(prd){
        console.log(Products.splice(Products.indexOf(prd),1));
        return Products;
    }
};