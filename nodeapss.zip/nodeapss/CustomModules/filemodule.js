var http = require('http');
var fs = require('fs');
exports.
getFiles=function(request){
    
    //1/create a server object with listener
    var server  = http.createServer(function(request,response){
      
        var requrl = [request.url];
                
    //2. parse the request and read url
    //if(request.url==='/home'){
    //2a.read for home page
    fs.readFile(requrl.concat(".html"),function(err,data){
        if(err){
            response.writeHead(401,{"Content-type":"text/html"});
            response.write("Resorce you are looking for is not available");
            response.end();
        }
        response.writeHead(200,{"Content-type":"text/html"});
        response.write(data);
        response.end();
    });
    //}else{
       
})
server.listen(4060);

    };

