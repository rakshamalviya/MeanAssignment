var util = require("./utilitymodules");
var math = require("./wholemodule");
var file = require("./filemodule");



var str = "Node.js";

console.log(`Case with upper for ${str} is ${util.caseUtility(str,"U")}`);
console.log(`Case with loer for ${str} is ${util.caseUtility(str,"L")}`);

console.log(`reverse with upper for ${str} is ${util.reverse(str)}`);

console.log(`Add = ${math.add(3,4)}`);
console.log(`multiplication = ${math.mult(3,4)}`);

var request={
    url:["./html1","./html2","./home","./about"]
}

file.getFiles(request);

