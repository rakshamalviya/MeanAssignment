module.exports={
    add:function(x,y){
        return parseInt(x)+parseInt(y);
    },

mult:function(x,y){
return parseInt(x)*parseInt(y);
}
}
