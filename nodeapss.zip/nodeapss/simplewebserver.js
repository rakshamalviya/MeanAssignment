var http =require('http');


var data=[
    {id:101,name:"A"},
    {id:102,name:"B"},
    {id:103,name:"C"},
    {id:104,name:"D"}
];
//1.create server

var server = http.createServer(function(request,response){
    

  //  response.writeHead(200,{"Content-type":"text/html"});
  //  response.write("Hello World!!!");
response.writeHead(200,{"Content-type":"application/json"});
response.write(JSON.stringify(data));
response.end();

});
//2/listen on port

server.listen(4050);
console.log("server started on port 4050");
