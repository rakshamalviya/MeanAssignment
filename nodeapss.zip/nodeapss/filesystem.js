//1.create a file and data in it


//2.Load the fs module
//generally module name and object name is kept same

var fs= require('fs');

//3. write file with sync call

fs.writeFileSync("./myfile.txt","I am the text file");
console.log("FIle is written");

//4.Read file with sync call
var data=fs.readFileSync('./myfile.txt');
console.log(data.toString());

