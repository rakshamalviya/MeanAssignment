console.log("Node.js");

var Employee={
    EmpNo:101,
    EmpName:"ABC"
};
console.log(JSON.stringify(Employee));
add(2,4);
function add(x ,y){
    var res=parseInt(x)+parseInt(y);
    console.log(res);
}