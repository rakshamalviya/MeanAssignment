var http = require('http');
 
var product = [];
 
//2.
var extServerOptions = {
    host: 'apiapptrainingservice.azurewebsites.net',
    path: '/api/products',
    method: 'GET'
   
};
//3.
function get() {
    http.request(extServerOptions, function (res) {
        res.setEncoding('utf8');
        res.on('data', function (data) {
            product = JSON.stringify(data);
            console.log(product);
          //  emp.foreach(function (e) {
        //        console.log(emp.ProductId + "\t" + emp.ProductName + "\t" + emp.CategoryName + "\t" + emp.Manufacturer + "\t" + emp.BasePrice+"\t" +emp.Description);
           // });
        });
 
    }).end();
};
 
//get();
 
console.log("Doing the Post Operations....");
//4
var product = JSON.stringify({
    'ProductId': '99',
    'ProductName': "IphoneX",
    'CategoryName': 'Phone',
    "Manufacturer":"Apple",
    'BasePrice': '99999',
    "Description":"Something"
});
 
 
//5
var extServerOptionsPost = {
    host: 'apiapptrainingservice.azurewebsites.net',
    path: '/api/products',
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': product.length
    }
};
 
 
 
//6
var reqPost = http.request(extServerOptionsPost, function (res) {
    console.log("response statusCode: ", res.statusCode);
    res.on('data', function (data) {
        console.log('Posting Result:\n');
        process.stdout.write(data);
        console.log('\n\nPOST Operation Completed');
    });
});
 
// 7
reqPost.write(product);
reqPost.end();
reqPost.on('error', function (e) {
    console.error(e);
});
 
get();