var http = require('http');
var callModule = require('./modulepost');
var fs = require('fs');
 
//2.
var serverDetails = {
    host: 'apiapptrainingservice.azurewebsites.net',
    path: '/api/products',
    method: 'GET'
};
 
var products = [];
//3.

var server = http.createServer(function(request,response){
      //console.log(request.url);
      //2. Parse the request and read URL.
      //if(request.url == '/get'){
            callModule.getData(serverDetails).then(function (resp) {
                        products = JSON.stringify(resp);
                        //console.log(products);
                        fs.writeFile('posttest.html',products,function(err){
                              //console.log(err.message);
                        });
                        fs.readFile('posttest.html',function(err,data){
                              if(err){
                                  response.writeHead(404,{'Content-Type':'text/html'});
                                  response.write('Resource is not found.');
                                  response.end();
                              }
                              else{
                                  response.writeHead(404,{'Content-Type':'text/html'});
                                  response.write(data.toString());
                                  response.end();
                              }
                          });
                  }).catch(function (err) {
                      console.log(err);
                  });
                   
                  console.log('Done');

          // }
      });

  server.listen(4080);
  console.log('server started on port 4080');

