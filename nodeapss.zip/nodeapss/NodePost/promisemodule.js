var callModule = require('./modulepost');
 
//2.
var serverDetails = {
    host: 'apiapptrainingservice.azurewebsites.net',
   // port: '39916',
    path: '/api/Products',
    method: 'GET'
};
 
var emp = [];
//3.
callModule.getData(serverDetails).then(function (response) {
      
    console.log("ProductId\tProductName\tCategoryName\tManufacturer\tDescription\tBasePrice");
    console.log();
    for (var i = 0; i < response.length; i++) {
        console.log(response[i].ProductId + "\t" + response[i].ProductName + "\t\t" + response[i].CategoryName + "\t" + response[i].Manufacturer + "\t\t" + response[i].Description + "\t\t" + response[i].BasePrice);
    }
}).catch(function (err) {
    console.log(err);
});
 
console.log('Done');