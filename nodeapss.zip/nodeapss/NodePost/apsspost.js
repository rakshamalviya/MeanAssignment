//1.
var http = require('http');
 
var emp = [];
 
//2.
var extServerOptions = {
    host: 'apiapptrainingservice.azurewebsites.net',
   // port: '3752',
    path: '/api/products',
    method: 'GET'
};
//3.
function get() {
    http.request(extServerOptions, function (res) {
        res.setEncoding('utf8');
        res.on('data', function (data) {
            prd = JSON.parse(data);
          //  prd.foreach(function (p) {
          //      console.log(p.PrdName + "\t" + p.price + "\t" + p.Category + "\t" + p.Manufacturer);
          //  });
          console.log(prd);
        });
 
    }).end();
};
 
get();
 
console.log("Doing the Post Operations....");
//4
var product = JSON.stringify({
    'ProductId':101,
    'ProductName': 'Desktop',
    'BasePrice': 52000,
    'CategoryName': 'Electronics',
    'Manufacturer': 'Dell',
    'Description':'Something'
});
 
 
//5
var extServerOptionsPost = {
    host: 'apiapptrainingservice.azurewebsites.net',
   // port: '3752',
    path: '/api/products',
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Content-Length': product.length
    }
};
 
 
 
//6
var reqPost = http.request(extServerOptionsPost, function (res) {
    console.log("response statusCode: ", res.statusCode);
    res.on('data', function (data) {
        console.log('Posting Result:\n');
        process.stdout.write(data);
        console.log('\n\nPOST Operation Completed');
    });
});
 
// 7
reqPost.write(product);
reqPost.end();
reqPost.on('error', function (e) {
    console.error(e);
});
 
get();